console.log('Question 1) program to search for a perticular character in a string');
let name = "Letsupgrade javascript session day 2 assignment";
console.log(name);
console.log(name.length);
// search method of string
console.log(name.search("session")); //The search() method searches a string for a specifiedvalue , and returns the positon of the match.
console.log(name.indexOf('t'));
console.log(name.lastIndexOf('t'));
console.log(name.charAt(9));    //the charAt() method returns the character at  the specified index in a string
console.log(name.charCodeAt(3)); //The charCodeAt  method returns the unicode of the character at a specified index in a string


//==============Question 2 (solution)=============
console.log('Question 2) Program to convert minute into second');
function convertMinutetoSecond(minutes) {
    return Math.floor(minutes*60);
}
let minutesToSecond= convertMinutetoSecond(28);
console.log('Result of converting minutes to second :' +    minutesToSecond );

//==============Question 3 (solution)===============
console.log('program to search for a element in array of string');
let array=[ 1,3,5,0.7,45,76,90,64,736483,'string', true,];
let search=array.find(function(element){
    return element>45
});
//printing desired values.
console.log(search);
// console.log(array);

//==============Question 5 (solution)=============
console.log('Question 4)Print an array in reverse order');
let arr=[1,4,5,6,7,8,9,0,9,8,7,6,56,58,44,37,92,23,44,56];
console.log(arr.reverse());